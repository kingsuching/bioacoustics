# UnderwaterAudioCapstone23

The objective of the pipeline is to give a .wav file and return a .txt file that gives bounding boxes by beginning and end for time as well as frequency. 
In __preprocessing.ipynb__, the inputted .wav file is first converted from a 1D array of amplitudes to a 2D spectrogram represented as a matrix with the dimensions 
representing time and frequency respectively. This conversion process is known as Short-Time Fourier Transform (STFT). The data is then normalized over each 
frequency bin in a process known as Per-Chanel Energy Normalization (PCEN). This is all the preprocessing phase. Now the data is fed into __model.ipynb__ where it 
is encoded and decoded through a dual neural network structure known as a variational autoencoder (VAE). The resulting spectrogram from this process is 
represented as an absolute value of the difference between the input and output of the VAE; a heatmap of reconstruction losses essentially. The preceding steps 
have now removed the vast majority of the background noise and allow using the bioacoustic analysis tool Scikit-maad. This library produces preliminary bounding 
boxes that are then cleaned up in __postprocessing.ipynb__ with duplicate boxes removed through a process known as Non-Maximum Suppression. The result will be a 
cleaned-up .txt file containing the start and end times/frequencies for the bounding boxes. This entire pipeline is all run iteratively in __main.ipynb__. For 
general use run __main.ipynb__ and it will run all of the three above .ipynb files in sequence. 

The __main.ipynb__ file will ask the user for a .wav file they would like annotations for. The .wav file is found in the same directory as the other decimated .wav 
files in the S3 bucket and then downloaded in the current notebook. PCEN is implemented on the .wav file, our model, __test_vae_mod_pcen__, loads up, and then we 
get bounding box predictions that NMS will clean up. The annotations are then formatted into a .txt file and the user will receive a message saying their .wav file
has been created. The user can then download the .txt file from the notebook instance which can be uploaded directly onto Raven Pro.
